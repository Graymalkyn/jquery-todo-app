'use strict';
if (this.ToDo === undefined) this.ToDo = {};

(function(context) {

  function start() {

  }

  context.start = start;

})(window.ToDo);
